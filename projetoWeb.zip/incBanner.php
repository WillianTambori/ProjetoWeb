<div class="bannerHome">
    <div class="slideshow" style="height: 0; overflow: hidden">
    <div class="slide" ><img src="img/carousel/carousel-1.jpg"></div>
    <div class="slide" ><img src="img/carousel/carousel-2.jpg"></div>
    <div class="slide" ><img src="img/carousel/carousel-3.jpg"></div>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="extraContent/lib/imagesloaded.js"></script>
    <script src="extraContent/lib/smartresize.js"></script>
    <script src="extraContent/src/jquery.skidder.js"></script>
    <script src="js/meusSlides.js"></script>
</div>