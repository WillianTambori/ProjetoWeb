<footer>
    <div class="content">
    <div>
    <p>
        <img src="img/logoFooter.jpg">
    </p>
    <p>Todos os direitos reservados 2023</p>
</div>
<div>
<div class="footerLista">
    <ul>
        <li><a href="login.php">Login</a></li>
        <li><a href="cadastroUsuario.php">Novo Usuário</a></li>
        <li><a href="usuario.php">Cadastrar/Editar Produto</a></li>
        <li><a href="contato.php">Contato</a></li>
    </ul>
</div>
</div>
<div class="footerLista">
    <p class="destaque">ALUNOS:</p>
    <ul>
        <li>Willian Diego Tambori</li>
        <li>Rogério Maciel de Souza</li>
        <li>Fabrício Tofano B. de Araújo</li>
    </ul>

</div>

    </div>

</footer>