<?php
var_dump($_FILES['perfil']);
?>